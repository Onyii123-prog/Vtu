<?php
session_start();
require_once 'includes/config.php';

// Redirect if not logged in
if (!is_logged_in()) {
    redirect('login.php');
}

// Initialize classes
$user = new User($pdo);
$transaction = new Transaction($pdo);

// Get user details
$user_details = $user->get_user($_SESSION['user_id']);
$user_balance = $user->get_balance($_SESSION['user_id']);
$recent_transactions = $transaction->get_user_transactions($_SESSION['user_id'], 5);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <?php include 'templates/header.php'; ?>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <!-- Sidebar -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">User Menu</h5>
                        <ul class="list-group">
                            <li class="list-group-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="list-group-item"><a href="buy-airtime.php">Buy Airtime</a></li>
                            <li class="list-group-item"><a href="buy-data.php">Buy Data</a></li>
                            <li class="list-group-item"><a href="pay-bills.php">Pay Bills</a></li>
                            <li class="list-group-item"><a href="transaction-history.php">Transaction History</a></li>
                            <li class="list-group-item"><a href="fund-wallet.php">Fund Wallet</a></li>
                            <li class="list-group-item"><a href="profile.php">Profile</a></li>
                            <li class="list-group-item"><a href="logout.php">Logout</a></li>
                        </ul>
                    </div>
                </div>
                
                <!-- Wallet Balance -->
                <div class="card mt-4">
                    <div class="card-body text-center">
                        <h6>Wallet Balance</h6>
                        <h3 class="text-primary"><?php echo format_currency($user_balance); ?></h3>
                        <a href="fund-wallet.php" class="btn btn-sm btn-success">Fund Wallet</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-9">
                <!-- Dashboard Content -->
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Welcome, <?php echo $user_details['username']; ?>!</h4>
                        
                        <!-- Quick Stats -->
                        <div class="row mt-4">
                            <div class="col-md-4">
                                <div class="card bg-primary text-white text-center">
                                    <div class="card-body">
                                        <h6>Total Transactions</h6>
                                        <h4><?php echo count($recent_transactions); ?></h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card bg-success text-white text-center">
                                    <div class="card-body">
                                        <h6>Successful</h6>
                                        <h4>
                                            <?php 
                                            $successful = array_filter($recent_transactions, function($t) {
                                                return $t['status'] === 'success';
                                            });
                                            echo count($successful);
                                            ?>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card bg-info text-white text-center">
                                    <div class="card-body">
                                        <h6>Wallet Balance</h6>
                                        <h4><?php echo format_currency($user_balance); ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Recent Transactions -->
                        <h5 class="mt-4">Recent Transactions</h5>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Service</th>
                                        <th>Amount</th>
                                        <th>Phone</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($recent_transactions)): ?>
                                        <tr>
                                            <td colspan="6" class="text-center">No transactions yet</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($recent_transactions as $t): ?>
                                        <tr>
                                            <td><?php echo substr($t['transaction_id'], 0, 8) . '...'; ?></td>
                                            <td><?php echo ucfirst($t['service_type']); ?></td>
                                            <td><?php echo format_currency($t['amount']); ?></td>
                                            <td><?php echo $t['phone']; ?></td>
                                            <td>
                                                <span class="badge badge-<?php 
                                                    echo $t['status'] === 'success' ? 'success' : 
                                                         ($t['status'] === 'pending' ? 'warning' : 'danger'); 
                                                ?>">
                                                    <?php echo ucfirst($t['status']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M j, Y g:i A', strtotime($t['created_at'])); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <a href="transaction-history.php" class="btn btn-outline-primary">View All Transactions</a>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="row mt-4">
                    <div class="col-md-4">
                        <div class="card text-center">
                            <div class="card-body">
                                <i class="fas fa-mobile-alt fa-2x mb-2 text-primary"></i>
                                <h5>Buy Airtime</h5>
                                <p>Instant airtime top-up</p>
                                <a href="buy-airtime.php" class="btn btn-primary">Buy Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card text-center">
                            <div class="card-body">
                                <i class="fas fa-wifi fa-2x mb-2 text-success"></i>
                                <h5>Buy Data</h5>
                                <p>Data bundles for all networks</p>
                                <a href="buy-data.php" class="btn btn-success">Buy Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card text-center">
                            <div class="card-body">
                                <i class="fas fa-bolt fa-2x mb-2 text-info"></i>
                                <h5>Pay Bills</h5>
                                <p>Electricity, TV subscriptions</p>
                                <a href="pay-bills.php" class="btn btn-info">Pay Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'templates/footer.php'; ?>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/fontawesome.min.js"></script>
</body>
</html>