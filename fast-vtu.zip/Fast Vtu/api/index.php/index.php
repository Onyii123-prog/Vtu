<?php
header('Content-Type: application/json');
require_once '../includes/config.php';

// API Authentication
$api_key = isset($_SERVER['HTTP_X_API_KEY']) ? $_SERVER['HTTP_X_API_KEY'] : '';
$stmt = $pdo->prepare("SELECT * FROM api_keys WHERE api_key = ? AND status = 'active'");
$stmt->execute([$api_key]);
$api_user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$api_user) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Invalid API key']);
    exit;
}

// Get request method and endpoint
$method = $_SERVER['REQUEST_METHOD'];
$endpoint = isset($_GET['endpoint']) ? $_GET['endpoint'] : '';

// Initialize classes
$user = new User($pdo);
$services = new Services($pdo);
$transaction = new Transaction($pdo);

// Route API requests
switch ($endpoint) {
    case 'balance':
        if ($method === 'GET') {
            $user_balance = $user->get_balance($api_user['user_id']);
            echo json_encode(['status' => 'success', 'balance' => $user_balance]);
        }
        break;
        
    case 'airtime':
        if ($method === 'POST') {
            $network = $_POST['network'] ?? '';
            $amount = $_POST['amount'] ?? 0;
            $phone = $_POST['phone'] ?? '';
            
            if (empty($network) || empty($amount) || empty($phone)) {
                echo json_encode(['status' => 'error', 'message' => 'Missing required parameters']);
                break;
            }
            
            $result = $services->process_airtime($api_user['user_id'], $network, $amount, $phone);
            echo json_encode($result);
        }
        break;
        
    case 'data':
        if ($method === 'POST') {
            $network = $_POST['network'] ?? '';
            $plan_id = $_POST['plan_id'] ?? '';
            $phone = $_POST['phone'] ?? '';
            
            if (empty($network) || empty($plan_id) || empty($phone)) {
                echo json_encode(['status' => 'error', 'message' => 'Missing required parameters']);
                break;
            }
            
            $result = $services->process_data($api_user['user_id'], $network, $plan_id, $phone);
            echo json_encode($result);
        }
        break;
        
    case 'transaction':
        if ($method === 'GET') {
            $transaction_id = $_GET['id'] ?? '';
            
            if (empty($transaction_id)) {
                echo json_encode(['status' => 'error', 'message' => 'Transaction ID required']);
                break;
            }
            
            $txn = $transaction->get_transaction($transaction_id);
            if ($txn) {
                echo json_encode(['status' => 'success', 'transaction' => $txn]);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Transaction not found']);
            }
        }
        break;
        
    default:
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'Endpoint not found']);
        break;
}
?>