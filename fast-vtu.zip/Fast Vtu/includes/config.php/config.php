<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'vtu_platform');
define('DB_USER', 'root');
define('DB_PASS', '');

// Site configuration
define('SITE_NAME', 'My VTU Platform');
define('SITE_URL', 'http://localhost/vtu-platform');
define('ADMIN_EMAIL', 'admin@myvtuplatform.com');

// Payment gateway configuration
define('PAYSTACK_SECRET_KEY', 'your_paystack_secret_key');
define('FLUTTERWAVE_SECRET_KEY', 'your_flutterwave_secret_key');

// Create database connection
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Include other necessary files
require_once 'functions.php';
require_once 'user.php';
require_once 'transaction.php';
require_once 'services.php';
?>