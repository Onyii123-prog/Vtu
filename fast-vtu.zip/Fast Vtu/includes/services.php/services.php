<?php
class Services {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    // Get all available services
    public function get_services() {
        $stmt = $this->pdo->prepare("SELECT * FROM services WHERE status = 'active' ORDER BY name");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Get service by ID
    public function get_service($service_id) {
        $stmt = $this->pdo->prepare("SELECT * FROM services WHERE id = ?");
        $stmt->execute([$service_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Get data plans for a network
    public function get_data_plans($network) {
        $stmt = $this->pdo->prepare("SELECT * FROM data_plans WHERE network = ? AND status = 'active' ORDER BY price");
        $stmt->execute([$network]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Get cable TV plans
    public function get_cable_plans($provider) {
        $stmt = $this->pdo->prepare("SELECT * FROM cable_plans WHERE provider = ? AND status = 'active' ORDER BY price");
        $stmt->execute([$provider]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Process airtime purchase
    public function process_airtime($user_id, $network, $amount, $phone) {
        // Deduct amount from user balance
        $user = new User($this->pdo);
        $current_balance = $user->get_balance($user_id);
        
        if ($current_balance < $amount) {
            return ['status' => 'error', 'message' => 'Insufficient balance'];
        }
        
        // Create transaction
        $transaction = new Transaction($this->pdo);
        $transaction_id = $transaction->create($user_id, 'airtime', $amount, $phone, $network);
        
        if (!$transaction_id) {
            return ['status' => 'error', 'message' => 'Failed to create transaction'];
        }
        
        // Call VTU API (this would be replaced with actual API integration)
        $api_response = $this->call_vtu_api('airtime', $network, $amount, $phone);
        
        if ($api_response['status'] === 'success') {
            // Update user balance
            $user->update_balance($user_id, -$amount);
            
            // Update transaction status
            $transaction->update_status($transaction_id, 'success', json_encode($api_response));
            
            return ['status' => 'success', 'message' => 'Airtime purchase successful', 'transaction_id' => $transaction_id];
        } else {
            $transaction->update_status($transaction_id, 'failed', json_encode($api_response));
            return ['status' => 'error', 'message' => 'Airtime purchase failed: ' . $api_response['message']];
        }
    }
    
    // Process data purchase
    public function process_data($user_id, $network, $plan_id, $phone) {
        // Get plan details
        $plan = $this->get_data_plan($plan_id);
        if (!$plan) {
            return ['status' => 'error', 'message' => 'Invalid data plan'];
        }
        
        $amount = $plan['price'];
        
        // Deduct amount from user balance
        $user = new User($this->pdo);
        $current_balance = $user->get_balance($user_id);
        
        if ($current_balance < $amount) {
            return ['status' => 'error', 'message' => 'Insufficient balance'];
        }
        
        // Create transaction
        $transaction = new Transaction($this->pdo);
        $transaction_id = $transaction->create($user_id, 'data', $amount, $phone, $plan_id);
        
        if (!$transaction_id) {
            return ['status' => 'error', 'message' => 'Failed to create transaction'];
        }
        
        // Call VTU API
        $api_response = $this->call_vtu_api('data', $network, $plan_id, $phone);
        
        if ($api_response['status'] === 'success') {
            // Update user balance
            $user->update_balance($user_id, -$amount);
            
            // Update transaction status
            $transaction->update_status($transaction_id, 'success', json_encode($api_response));
            
            return ['status' => 'success', 'message' => 'Data purchase successful', 'transaction_id' => $transaction_id];
        } else {
            $transaction->update_status($transaction_id, 'failed', json_encode($api_response));
            return ['status' => 'error', 'message' => 'Data purchase failed: ' . $api_response['message']];
        }
    }
    
    // Simulate VTU API call (replace with actual API integration)
    private function call_vtu_api($service_type, $network, $amount, $phone) {
        // This is a simulation - replace with actual API calls to your VTU provider
        $success_rate = 0.95; // 95% success rate for simulation
        
        if (rand(1, 100) <= ($success_rate * 100)) {
            return [
                'status' => 'success',
                'message' => 'Transaction completed successfully',
                'reference' => 'API' . time() . rand(1000, 9999)
            ];
        } else {
            return [
                'status' => 'failed',
                'message' => 'Network error, please try again'
            ];
        }
    }
}
?>