<?php
class Transaction {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    // Create new transaction
    public function create($user_id, $service_type, $amount, $phone, $plan = null) {
        $transaction_id = generate_transaction_id();
        $status = 'pending';
        
        $stmt = $this->pdo->prepare("INSERT INTO transactions (user_id, transaction_id, service_type, amount, phone, plan, status, created_at) 
                                     VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
        
        if ($stmt->execute([$user_id, $transaction_id, $service_type, $amount, $phone, $plan, $status])) {
            return $transaction_id;
        }
        
        return false;
    }
    
    // Update transaction status
    public function update_status($transaction_id, $status, $api_response = null) {
        $stmt = $this->pdo->prepare("UPDATE transactions SET status = ?, api_response = ?, updated_at = NOW() WHERE transaction_id = ?");
        return $stmt->execute([$status, $api_response, $transaction_id]);
    }
    
    // Get transaction by ID
    public function get_transaction($transaction_id) {
        $stmt = $this->pdo->prepare("SELECT * FROM transactions WHERE transaction_id = ?");
        $stmt->execute([$transaction_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Get user transactions
    public function get_user_transactions($user_id, $limit = 10) {
        $stmt = $this->pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
        $stmt->bindValue(1, $user_id, PDO::PARAM_INT);
        $stmt->bindValue(2, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Get all transactions (for admin)
    public function get_all_transactions($limit = 50) {
        $stmt = $this->pdo->prepare("SELECT t.*, u.username FROM transactions t 
                                     JOIN users u ON t.user_id = u.id 
                                     ORDER BY t.created_at DESC LIMIT ?");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>