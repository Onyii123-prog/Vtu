<?php
class User {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    // Register new user
    public function register($username, $email, $password, $phone) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $verification_code = md5(uniqid(rand(), true));
        
        $stmt = $this->pdo->prepare("INSERT INTO users (username, email, password, phone, verification_code, created_at) 
                                     VALUES (?, ?, ?, ?, ?, NOW())");
        
        if ($stmt->execute([$username, $email, $hashed_password, $phone, $verification_code])) {
            // Send verification email
            $verification_link = SITE_URL . "/verify.php?code=" . $verification_code;
            $subject = "Verify Your Account";
            $message = "Please click the following link to verify your account: " . $verification_link;
            
            send_email($email, $subject, $message);
            
            return true;
        }
        
        return false;
    }
    
    // Login user
    public function login($email, $password) {
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE email = ? AND verified = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['username'] = $user['username'];
            
            // Update last login
            $this->update_last_login($user['id']);
            
            return true;
        }
        
        return false;
    }
    
    // Update last login
    private function update_last_login($user_id) {
        $stmt = $this->pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $stmt->execute([$user_id]);
    }
    
    // Get user by ID
    public function get_user($user_id) {
        $stmt = $this->pdo->prepare("SELECT id, username, email, phone, balance, role, created_at FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Update user wallet balance
    public function update_balance($user_id, $amount) {
        $stmt = $this->pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        return $stmt->execute([$amount, $user_id]);
    }
    
    // Get user balance
    public function get_balance($user_id) {
        $stmt = $this->pdo->prepare("SELECT balance FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['balance'] : 0;
    }
}
?>