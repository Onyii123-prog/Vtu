<?php
session_start();
require_once 'includes/config.php';

// Initialize classes
$user = new User($pdo);
$services = new Services($pdo);

// Get all available services
$all_services = $services->get_services();

// Handle user login
$login_error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = sanitize_input($_POST['email']);
    $password = sanitize_input($_POST['password']);
    
    if ($user->login($email, $password)) {
        redirect('dashboard.php');
    } else {
        $login_error = 'Invalid email or password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - VTU Services</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php"><?php echo SITE_NAME; ?></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
                    <li class="nav-item"><a class="nav-link" href="pricing.php">Pricing</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                    <?php if (is_logged_in()): ?>
                        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="register.php">Register</a></li>
                        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero bg-light py-5">
        <div class="container text-center">
            <h1 class="display-4">VTU Services Made Easy</h1>
            <p class="lead">Buy airtime, data, pay bills and more at the best rates</p>
            <a href="register.php" class="btn btn-primary btn-lg">Get Started</a>
        </div>
    </section>

    <!-- Services Section -->
    <section class="services py-5">
        <div class="container">
            <h2 class="text-center mb-5">Our Services</h2>
            <div class="row">
                <?php foreach ($all_services as $service): ?>
                <div class="col-md-4 mb-4">
                    <div class="card service-card h-100">
                        <div class="card-body text-center">
                            <div class="service-icon mb-3">
                                <i class="fas fa-<?php echo $service['icon']; ?> fa-3x"></i>
                            </div>
                            <h5 class="card-title"><?php echo $service['name']; ?></h5>
                            <p class="card-text"><?php echo $service['description']; ?></p>
                            <a href="service.php?id=<?php echo $service['id']; ?>" class="btn btn-outline-primary">Buy Now</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- How It Works -->
    <section class="how-it-works bg-light py-5">
        <div class="container">
            <h2 class="text-center mb-5">How It Works</h2>
            <div class="row">
                <div class="col-md-4 text-center">
                    <div class="step mb-3">
                        <span class="step-number">1</span>
                    </div>
                    <h4>Create Account</h4>
                    <p>Sign up and fund your wallet</p>
                </div>
                <div class="col-md-4 text-center">
                    <div class="step mb-3">
                        <span class="step-number">2</span>
                    </div>
                    <h4>Choose Service</h4>
                    <p>Select from airtime, data, bills, etc.</p>
                </div>
                <div class="col-md-4 text-center">
                    <div class="step mb-3">
                        <span class="step-number">3</span>
                    </div>
                    <h4>Instant Delivery</h4>
                    <p>Receive your service instantly</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5><?php echo SITE_NAME; ?></h5>
                    <p>Your reliable partner for all VTU services</p>
                </div>
                <div class="col-md-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-white">Home</a></li>
                        <li><a href="services.php" class="text-white">Services</a></li>
                        <li><a href="about.php" class="text-white">About Us</a></li>
                        <li><a href="contact.php" class="text-white">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Contact Us</h5>
                    <p>Email: <?php echo ADMIN_EMAIL; ?></p>
                    <p>Phone: +234 123 456 7890</p>
                </div>
            </div>
            <div class="text-center mt-3">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/fontawesome.min.js"></script>
</body>
</html>